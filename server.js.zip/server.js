var express= require('express');
var mysql= require('mysql');



var parser= require('body-parser');
var urlEncoded = parser.urlencoded({extended:false});
var morgan = require('morgan'); // Charge le middleware de logging
var favicon = require('serve-favicon'); // Charge le middleware de favicon

var app= express();


var connection = mysql.createConnection({
  host     : '127.0.0.1:8889',
  user     : 'root',
  password : 'root',
  database : 'demo',
  socketPath: '/Applications/MAMP/tmp/mysql/mysql.sock'
});



connection.connect(function(err){
if(!err) {
    console.log("Database is connected ... oui");    
} else {
    console.log("Error connecting database ... nn");    
}
});
 


 app.get('/',function (req,res) {


      console.log(__dirname);

      res.sendFile(__dirname + '/index.html');

 });

app.get('/all',function (req,res) {
  

connection.query('SELECT * from Client', function(err, rows) {
  if (!err) {
    console.log('The solution is: ', rows);
res.send(rows); 
//res.send(JSON.stringify(response));


 } else {
    console.log('Error while performing Query.');
}
    
 
 });     

 
 }); 


app.get('/recherche',function (req,res) {


     var sql="SELECT * from Client where nom='"+req.query.nom+"'";


     console.log(sql);


connection.query(sql, function(err, rows) {
  if (!err) {
    console.log('The solution is: ', rows);
res.send(rows); 
//res.send(JSON.stringify(response));


 } else {
    console.log('Error while performing Query.');
}
    
 
 });     






 
 });  



app.get('/add',function (req,res) {
     var sql="INSERT INTO `CLIENT`(`ADRESSE`, `EMAIL`, `LATITUDE`, `LONGITUDE`, `NOM`, `PASSWORD`, `PRÉNOM`) VALUES ('"+req.query.adresse+"','"+req.query.email+"',"+req.query.lat+","+req.query.lng+",'"+req.query.nom+"','"+req.query.pwd+"','"+req.query.prenom+"') ";
     console.log(sql);
connection.query(sql, function(err, rows) {
  if (!err) {
    console.log('The solution is: ', rows);
res.send(rows); 
//res.send(JSON.stringify(response));


 } else {
    console.log('Error while performing Query.');
}
  
 });      
 });  



app.get('/remove',function (req,res) {

      var sql="DELETE FROM `CLIENT` WHERE id="+req.query.id;


     console.log(sql);


connection.query(sql, function(err, rows) {
  if (!err) {
    console.log('The solution is: ', rows);
res.send(rows); 
//res.send(JSON.stringify(response));


 } else {
    console.log('Error while performing Query.');
}
    
 
 });     


 });  



app.get('/update',function (req,res) {

      
      var sql="UPDATE `CLIENT` SET `ADRESSE`='"+req.query.adresse+"',`EMAIL`='"+req.query.email+"',`NOM`='"+req.query.nom+"',`PASSWORD`='"+req.query.pwd+"',`PRÉNOM`='"+req.query.prenom+"' WHERE id="+req.query.id;


     console.log(sql);


connection.query(sql, function(err, rows) {
  if (!err) {
    console.log('The solution is: ', rows);
res.send(rows); 
//res.send(JSON.stringify(response));


 } else {
    console.log('Error while performing Query.');
}
    
 
 });     


 });   


 


app.get('/authenGET',function (req,res) {
  
  var response = {
 
           login : req.query.login,
           password : req.query.password,
           
  }
   
res.send(JSON.stringify(response));
 
 });  



app.post('/authenPOST',urlEncoded,function (req,res) {
  
  var response = {
 
           login : req.body.login,
           password : req.body.password,
           
  }

  console.log(response);
  
    
res.send(JSON.stringify(response));
 
 });   


app.get('/addget',function (req,res) {


     response = {

         firstname : req.query.firstname,
         lastname : req.query.lastname

     }

    console.log(response);

     res.send(JSON.stringify(response));

});


app.post('/addpost',urlEncoded,function (req,res) {


    response = {

        firstname : req.body.firstname,
        lastname : req.body.lastname

    }

    console.log(response);

    res.send(JSON.stringify(response));

});

app.get('/:id/test', function(req, res) {
    res.setHeader('Content-Type', 'text/plain');
    res.end('Vous êtes à la chambre de l\'étage n°' + req.params.id);
});


app.get('/:id/chambre', function(req, res) {
    res.render('chambre.ejs', {etage: req.params.id});
});

app.get('/compter/:nombre', function(req, res) {
    var noms = ['Robert', 'Jacques', 'David'];
    res.render('chambre.ejs', {compteur: req.params.nombre, noms: noms});
});


app.use(morgan('combined')) // Active le middleware de logging
    .use(express.static(__dirname + '/public')) // Indique que le dossier /public contient des fichiers statiques (middleware chargé de base)
    .use(favicon(__dirname + '/images/logo.jpg')) // Active la favicon indiquée
    .use(function(req, res){ // Répond enfin
        res.send('Hello');

    });



app.use(function(req, res, next){
    res.setHeader('Content-Type', 'text/plain');
    res.send(404, 'Erreur 404');
    //res.sendFile(__dirname + '/index.html');
});




  console.log("my server url : locahost:3000");
 app.listen(3000);

